# KCI-Align：新增不同知识依赖与任务路径的合成 CI 数据集（长期分支版）

构建日期：2026-11-19。数据位于本机 D:\research\longhistory\artifacts\20261119_composition_signals\diverse_ci_long_horizon_v2。

**项目定位：可执行、受控、自动打分的多 Agent CI 数据开发集。尚非正式论文 Benchmark，也不是人工认证的现实社会隐私规范或已训练 RL 模型。**

## 1. 真正新增的结构

不是对原十个任务重命名：新建了七种 Horn 规则超图（保留实际规则节点与中间结论节点进行有向超图同构检验，全部两两不互为同构）：

| 新知识依赖结构 | 最小证明构造 | 研究行为 |
|---|---|---|
| quorum2of3 | 三个信号中任意两个即可推导 | 一个先前信号使同一当前消息变得违规 |
| quorum3of5 | 五个信号中任意三个即可推导 | 必须识别此前多个信号是否已累计到阈值 |
| unequal_or | (A 与 B) 或 (C 与 D 与 E)，通过两层规则合并 | 两条不等长的替代推理路径 |
| cascade3 | 连续三次中间知识推导 | 历史线索与最后一步作用跨多个推导层 |
| parallel_join | 两个子证据对分别成立，之后再汇合 | 两个分支的完整知识汇合 |
| asymmetric_paths | 三步链和二条线索的替代通道 | 先保护一条线路可能仍在另一条线路违规 |
| staged_bridge | 四层递进的中间事实链 | 更长依赖深度的归因 |

每个原生图使用六个可送达源信号（附加中间事实节点），每个信号绑定一个可校验的、由模拟业务当前字段生成的文本消息。模型看到的事实和 CI 规则是公开给定的受控符号知识；隐藏打分仅根据真实送达给 R 的事实推理。

## 2. 三种真正不同的业务分支

**Calendar（日历）**
- 检索真实模拟日历：早时段空闲则应安排早时段；已占用则切换晚时段；两个时段都占用必须给出“无可用时段”的真实报告，不能伪造预约。
- 晚时段路径会将一个原本参与私密推理的来源信号替换成业务上实际不同的普通信号。它不仅改变了语句，也改变了接收者可能获得的原始事实集合。

**Retail（订单）**
- pending 且得到明确同意：取消并真实修改订单；delivered 且同意：退货并真实修改订单。
- pending 但用户拒绝修改：不能自动假装同意，必须改为只读状态摘要，订单状态保持不变。这是合法任务路径而非随便拒绝。

**Document（文档审查和受信代理）**
- Internal recipient 有明确例外授权，可以在较短时限内直接完成。
- External recipient 不得推导受限关联，可以预先开通隐私证明通道，或改由被授权的中间代理 M 接收 raw 文档，再向 R 发送不暴露 raw 的受信证明。
- R 和 M 拥有**相互独立的知识和消息历史**，给 M 发送的东西不会在 M 转发前直接计入 R。

这些分支的终局会修改模拟日历、订单或接收者文档记录；不再只看文本中是否出现“success”。

## 3. 主要创新实验条件：早期隐私准备改变未来的动作集合

初版的私下验证按钮可以在任何披露步骤临时使用，因此能看懂推理规则的简单“看到即时危险就验证”控制器在 56/56 可完成条件下成功。

长期分支版加入真实的前置约束：
- 信息收集前必须二选一：OPEN_PRIVATE_CHANNEL（占用两步）或 SKIP_PRIVATE_CHANNEL（占用一步）。
- 如果在开头跳过，之后不能在单步信息披露决策中突然激活私下验证。受信中间代理是另一种需要此前选对业务路由的替代路径。
- 开通通道有时间和操作成本，在授权内部收件人的短时限条件下无须开通；强行开通会耽误任务。
- 用户拒绝业务修改后直接转只读报告；两个日历时段都忙则直接报告无可用时段。这些都是可执行的**后续任务路径变化**。

因此，仅看当前披露是否违规，不足以决定最开始要不要申请保护通道。

## 4. 长期分支版真实 CPU 基线（63 个业务条件）

| 策略 | 合规完成 | 违规 | 安全未完成 |
|---|---:|---:|---:|
| 永远跳过事前准备，然后只处理眼前违规 | 28/63 | 0 | 35 |
| 总是提前开通保护，之后按知识规则处理 | 56/63 | 0 | 7 |
| 读取已给定规则与收件人权限、按条件开通的手写控制器 | 63/63 | 0 | 0 |
| 充分访问当前完整模拟状态、枚举有限合法保护决策的参考规划器 | 63/63 | 0 | 0 |

重要解释：这里的“手写控制器”具有精确的公开规则和接收者送达知识，能按当前业务/授权条件选择提前准备。**它仍然达到 63/63，所以这批数据不能用来声称 RL 优于规则系统。** 相比第一版，这些任务能区分短视局部策略与含早期规划的策略，但仍然不是对真实 Agent 自然语言能力或跨域泛化的结论。

本表只是 CPU 逻辑代理的确定性成功计数；所有策略的实际动作细节见 CPU_POLICY_BASELINES.json。这里没有 Qwen 4B、GRPO、GiGPO、DPO 或其它神经模型结果，也没有随机种子平均。

## 5. 数据量与泄漏隔离

| 数据项 | 数量 |
|---|---:|
| 不同的业务 × 知识结构组合根 | 21 |
| 独立逻辑依赖结构 | 7 |
| 业务控制流程种类 | 3 |
| 可恢复业务/历史世界 | 189 |
| 可提供给模型的原生决策观察 | 539 |
| Flip/Hold/权限与业务分支成对对照 | 105 |
| 来源行动立即安全标签（仅评估） | 175 |
| 真实模拟多步业务执行路径 | 168 |
| 中间代理分接收者验证记录 | 7 |

严格按**知识图家族**做分组：4 组图（12 根）train、1 组图（3 根）dev、2 组图（6 根）exploratory test。这比只对同一业务模板换字符串划分更严格。但由于这些图已参与我们开发分析，所谓 exploratory test 仍**不是独立盲测**。

一次任务根下的九种历史/业务条件变体是相关样本，不是九个独立真实业务来源；源业务流程的类型也只有三种，不能声称有 21 个独立企业环境。

### 关键安全与效用性质

- 逻辑知识随实际送达消息单调积累；不允许后来撤回一条已读消息就假装接收者不知道。
- 改变发送顺序可以改变首次违规的实际步骤；由于系统在检测到违规时立即终止，两个路线的**计划发送集合相同**，但**实际已送达前缀**可能不同。论文不能混淆。
- 完成工作流必须有真正的业务最终状态；直接中止不能被算作完成。
- 全部私下验证的冗余费用会超时，单纯全部拒绝不能混高成功率。
- 受信中间代理与最终接收者知识相互独立，不能把代理所知直接算成 R 所知。
- 模型输入不得包含 evaluator 的正确标签、奖励、未来 Q 或隐藏状态。标签仅在文件名包含 EVAL_ONLY 的文件中。

## 6. 数据和源代码

本版本数据目录：
- ROOTS.jsonl — 21 个任务根、独立知识拓扑及 split
- KNOWLEDGE_GRAPHS.jsonl — 7 张图全部 Horn 规则和最小证明集合
- WORLDS.jsonl — 189 个世界、历史/业务状态和授权条件
- MODEL_INPUTS.jsonl — 539 条原生 Agent 决策观察，模型可见
- CONTRASTS_EVAL_ONLY.jsonl — 105 组反事实和分支对照（不能直接当终局 DPO 偏好）
- PIVOT_ACTION_LABELS_EVAL_ONLY.jsonl — 175 个指定 source disclosure 动作的事实性立即违规结果
- REAL_TRACES_EVAL_ONLY.jsonl — 168 条真实工具/消息执行记录
- BROKER_TRACES_EVAL_ONLY.jsonl — 7 个跨接收者来源路径
- CPU_POLICY_BASELINES.json — 63 条条件 × 4 个 CPU 手写/规划基线
- VALIDATION.json、MANIFEST_SHA256.json、INDEPENDENT_AUDIT.json — 构建和独立回放证据

原生引擎、生成器与审计：
- code/kci/diverse_ci_branch_env.py
- code/kci/diverse_ci_long_horizon_env.py
- tools/build_diverse_ci_long_horizon_dataset.py
- tools/audit_diverse_ci_long_horizon_dataset.py
- tools/baseline_diverse_ci_long_horizon_cpu.py
- tools/pilot_diverse_ci_long_horizon.py
- code/tests/test_diverse_ci_branch_env.py
- code/tests/test_diverse_ci_long_horizon_env.py

## 7. 复现（只用本机 CPU）

在 D:\research\longhistory 运行：

    py -3 -m unittest discover -s code\tests -p "test_diverse_ci*py" -v

    py -3 tools\build_diverse_ci_long_horizon_dataset.py --output artifacts\20261119_composition_signals\diverse_ci_long_horizon_rebuild

    py -3 tools\audit_diverse_ci_long_horizon_dataset.py --dataset artifacts\20261119_composition_signals\diverse_ci_long_horizon_rebuild

    py -3 tools\baseline_diverse_ci_long_horizon_cpu.py

生成器严格拒绝覆盖已有目录。本目录不依赖模型、付费 API 或 GPU。

## 8. 对论文方法的实际意义和下一步

这批数据展示了两个结构不同的学习困难：
1. 当前披露的后果依赖 R 的过去消息与多步推导规则；
2. 一步合规的局部决策未必能导致任务成功，因为之前是否注册隐私通道、是否选择受信中间代理或替代业务路线，已经限制了后续选择。

但**知道全部公开规则的手写控制器目前仍能 63/63**。所以不能仅凭数据构建成功宣称学到了泛化策略，也不能仅凭引入 preflight 就宣称有新的 RL 算法贡献。需要把这个数据与真实的 LLM Agent 冻结评测接起来，并设计更自然、非固定模板的独立任务族；强符号规则控制器必须保留。

此外，隐私规范是明确声明的虚构组织政策，没有经外部人类认证的真实社会价值判断；这不妨碍开始 RL 方法开发，但论文的规范范围和适用性必须明确。
