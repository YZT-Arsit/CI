# KCI-Align · 十个公开业务流程衍生任务的统一证据绑定数据 v1

2026-11-19 本机 CPU 实际生成与回放。

**这批数据是合成多 Agent CI 学习环境开发数据，不是已经认证的论文 Benchmark 或正式训练集。** 10 个任务分别参考了 MIT 许可证下的 AgentDojo Workspace（5 项）和 τ²-bench Retail（5 项）的公开工具工作流。业务数据、规范、隐私身份和知识关联都是研究者自建的虚构内容，没有复用真实客户资料，也没有运行官方上游 harness。

## 1. 本轮新产生了什么

之前 W01（会议创建）、R03（修改待处理订单）已经各自证据绑定并 CPU 检查。本轮没有覆盖旧数据，而是继续实现余下八个任务：

- W02：真正根据搜索到的源事件 ID/标题执行改期，同时检查新时段冲突
- W03：核对目标事件、联系人和明确允许邀请的地址
- W04：从原始 TODO 文件解析三组负责人、工作内容与截止日，再生成发给每个人的邮件；没有有效清单不能完成
- W05：从真实源文件提取打包项目、生成新文件并共享给指定收件人；源文件改变，输出文件相应改变
- R01：检查交付订单、换货变体库存、同商品类型和差价支付
- R02：核对交付订单、退货条目、原付款渠道及允许的退款方式
- R04：核验客户身份、订单所有权及 pending 状态，写入用户指定的新地址
- R05：只使用用户真实提供的允许取消理由，在明确同意后取消 pending 订单

此外，沿用 W01/R03 已证明的封闭世界受信事实约束：来源记录、声明事实、受控自然语言消息、当时的工具返回和发送证书必须一致；发现不一致则返回 UNKNOWN，不按旧隐藏事实 ID 悄悄打分。接收者的已送达消息必须保持历史不可变。

## 2. 统一数据规模

| 单位 | 实际数量 |
|---|---:|
| 不同公开任务根 | **10** |
| 可恢复场景 | **80** |
| 模型可见实际动作观察 | **80** |
| 同动作 Flip / Hold / Permission 成对对照 | **30** |
| 完整工具+接收者知识轨迹 | **60** |
| 业务错误或来源语言篡改的 CPU 负例 | **24** |

每根任务 8 个场景（5 个 minimal 即时行动探针 + 3 个 full 任务环境）。同一根衍生的多个场景**不是独立业务任务**，不要把 80 当成 80 个独立训练根。

划分按根实现：6 train、2 dev、2 exploratory test。测试集已经被开发者检查过，**不是盲测集**。每根 Flip/Hold 及其所有变体保持相同 split。

## 3. 信号可验证而不是文本标签凑数

每条 source record 保留当前合法角色、来源工具、可见文本与内部精确来源事实。当前候选动作相同、接收者收到过的相关信息不同时，在 Flip 条件下产生不同知识事件和即时违规结果；Hold 对照更换无关历史而不改变正确即时判断；授权对照保留知识变化但允许适用的接收者获得该关系。

全量原生执行中，全部直接公开会造成知识违规，全部走受信内部私下验证则在当前任务预算内无法完成；选择性安全路径可以让模拟数据库真正发生目标变更。合法信息到达顺序改变时，首次违规的动作/步骤可以变化。

异常数据干预与失败输出保持在 EVAL ONLY 文件中，**不能作为未经核验的 Step-DPO 优选标签**。评估器的隐藏事实、受保护知识闭包及终局奖励都不送入模型输入。

## 4. 真实执行与机器校验结果

- 之前 W01/R03：16 场景、6 对照、12 条真实回放、8 项独立负例，独立审计通过。
- 新增八项：64 场景、24 对照、48 条真实回放、16 项独立负例，独立审计通过。
- 统一数据交叉检查：10 根、80 输入、30 对照、60 轨迹、24 负例、SHA-256 均通过；未发现同一根跨 train/DEV/test。
- 旧版及新版相关 44 项单元/回归测试通过（32+4+8）。
- 本次零付费 API、零 GPU、零模型训练、零额外真实私人数据上传。

## 5. 文件结构

本统一目录：

- ROOTS.jsonl：10 根任务、来源及 split。
- WORLDS.jsonl：80 个可恢复模拟情境的元数据。
- MODEL_INPUTS.jsonl：模型真实可见的 80 个观察、动作列表。**模型只能读取该文件 model_input 字段及环境授权观察。**
- CONTEXT_PAIRS_EVAL_ONLY.jsonl：30 组历史/授权对照标签。
- FULL_TRACES_EVAL_ONLY.jsonl：60 条实际模拟业务与知识执行轨迹。
- NEGATIVE_CONTROLS_EVAL_ONLY.jsonl：24 项负例及结果。
- VALIDATION.json、MANIFEST_SHA256.json、INDEPENDENT_CROSS_FAMILY_AUDIT.json：数量、来源、内容校验与边界。
- README_CN.md：本说明。

基础两项独立文件夹：
artifacts/20261119_composition_signals/public_workflow_grounded_W01_R03_v1

新八项独立文件夹：
artifacts/20261119_composition_signals/public_workflow_remaining_8_grounded_v1

原始未经修订的十任务留在 public_workflow_ci_10_final，未被覆盖。

## 6. 复现命令（Windows CPU）

在 D:\research\longhistory：

    py -3 -m unittest discover -s code\tests -p "test_public_workflow_ci*py" -v

    py -3 tools\build_public_ci_remaining_grounded.py --output artifacts\20261119_composition_signals\public_workflow_remaining_8_rebuild

    py -3 tools\audit_public_ci_remaining_grounded.py --dataset artifacts\20261119_composition_signals\public_workflow_remaining_8_rebuild

    py -3 tools\assemble_public_ci_all10_grounded.py --output artifacts\20261119_composition_signals\public_workflow_all10_rebuild

    py -3 tools\audit_public_ci_all10_grounded.py --dataset artifacts\20261119_composition_signals\public_workflow_all10_rebuild

所有生成器拒绝覆盖已有路径，以防止修改冻结实验。

## 7. 研究边界及下一道关口

- **还不是论文级语义/策略泛化 benchmark**：当前关系表达仍有明确语法模板，专门文本解析和符号规划可能很好解决；不能用这批小型开发数据证明 RL 的必要性。
- CI 规范是可验证的**虚构组织规范**，没有真实企业授权或独立人类对社会规范合理性的认证；只适合检验模型能否遵守给定政策。
- 十项任务均只是从公开业务任务借鉴了工具名称、业务目标和数据结构，不等于上游官方任务语义完整重现。
- 当前生成数量增加的是**受控历史/规范/路径变化覆盖**，不是独立来源的增量。直接把现有 10 种结构随机换名字扩到 2,000 条不会增加独立推理能力。
- 需要冻结 4B 或其他实际策略的真实行动评测，和能够读取同样可见信息的强文本符号规划器进行同条件对照。模型收益尚未建立。
- 新的业务任务机制/未见语言表达需要来源绑定、反例检查及真正封存的盲测，而不能只靠 GPT 自由改写。
- 你不必亲自编造数百条案例。现有构造/审核/回放脚本可以继续由助手维护；研究规范口径的最后选择可以在论文阶段明确，不阻止进一步实验。
